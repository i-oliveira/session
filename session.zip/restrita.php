<?php include 'lock.php'; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Página Restrita</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
</head>
<body class="container">

	<?php include 'menu.php'; ?>

	<h2>Página Restrita</h2>
	<h4>Login Confirmado!</h4>

</body>
</html>
